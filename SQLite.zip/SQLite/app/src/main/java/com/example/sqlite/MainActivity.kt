package com.example.sqlite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var listaView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var listaItens: MutableList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)
        listaView = findViewById(R.id.listaView)
        listaItens = dbHelper.lerItens().toMutableList()

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaItens)
        listaView.adapter = adapter

        val editTextItem = findViewById<EditText>(R.id.editTextItem)
        val botaoAdicionar = findViewById<Button>(R.id.botaoAdicionar)

        botaoAdicionar.setOnClickListener {
            val item = editTextItem.text.toString()
            if (item.isNotEmpty()) {
                dbHelper.inserirItem(item)
                listaItens.add(item)
                adapter.notifyDataSetChanged()
                editTextItem.text.clear()
            }
        }

        listaView.setOnItemClickListener { _, _, position, _ ->
            val item = listaItens[position]
            if (dbHelper.excluirItem(item)) {
                listaItens.removeAt(position)
                adapter.notifyDataSetChanged()
            }
        }
    }
}
