package com.example.urnaeletronica

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var votosSim = 0
    private var votosNao = 0

    private lateinit var textoContagem: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textoContagem = findViewById(R.id.texto_contagem)

        val botaoSim: Button = findViewById(R.id.botao_sim)
        val botaoNao: Button = findViewById(R.id.botao_nao)
        val botaoResultado: Button = findViewById(R.id.botao_resultado)

        botaoSim.setOnClickListener {
            votosSim++
            atualizarContagem()
        }

        botaoNao.setOnClickListener {
            votosNao++
            atualizarContagem()
        }

        botaoResultado.setOnClickListener {
            irParaResultado()
        }
    }

    private fun atualizarContagem() {
        textoContagem.text = "Votos SIM: $votosSim\nVotos NÃO: $votosNao"
    }

    private fun irParaResultado() {
        val intent = Intent(this, ResultadoActivity::class.java).apply {
            putExtra("votosSim", votosSim)
            putExtra("votosNao", votosNao)
        }
        startActivity(intent)
    }
}
