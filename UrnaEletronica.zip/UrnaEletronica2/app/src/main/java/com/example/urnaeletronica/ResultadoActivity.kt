package com.example.urnaeletronica

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultadoActivity : AppCompatActivity() {

    private lateinit var textoResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        textoResultado = findViewById(R.id.texto_resultado)

        val votosSim = intent.getIntExtra("votosSim", 0)
        val votosNao = intent.getIntExtra("votosNao", 0)

        val resultado = "Votos SIM: $votosSim\nVotos NÃO: $votosNao"
        textoResultado.text = resultado
    }
}
